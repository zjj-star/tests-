````
    Install openLDAP and phpldapadmin with persistent to kubernetes.
    Detail: https://www.cnblogs.com/dukuan/p/9983899.html
    持久化安装openLDAP和phpldapadmin到k8s
    部署文档:https://www.cnblogs.com/dukuan/p/9983899.html
````
