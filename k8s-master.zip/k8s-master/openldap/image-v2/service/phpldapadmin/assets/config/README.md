Add your custom config.php file here or mount one at docker run to /container/service/phpldapadmin/assets/config/config.php
