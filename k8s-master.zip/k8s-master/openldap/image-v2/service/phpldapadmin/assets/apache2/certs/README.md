Add your https server certificate, key and the CA certificate (if any) here
or during docker run mount a data volume with those files to /container/service/phpldapadmin/assets/apache2/certs
