Add your ldap client certificate, key and CA certificate here
or during docker run mount a data volume with those files to /container/service/ldap-client/assets/certs
