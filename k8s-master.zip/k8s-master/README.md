# k8s
````
    Install EFK: https://www.cnblogs.com/dukuan/p/9891198.html
    Install RabbitMQ Cluster: https://www.cnblogs.com/dukuan/p/9897443.html
    Install openLDAP: https://www.cnblogs.com/dukuan/p/9983899.html
    Install Redis Sentinel: https://www.cnblogs.com/dukuan/p/9913420.html
    Install Redis Cluster: https://github.com/dotbalo/k8s/tree/master/redis/k8s-redis-cluster
    Install GitLab: https://www.cnblogs.com/dukuan/p/10036489.html
````


# 超全面、超详细的Kubernetes视频教程，基于最新K8s进行讲解
# 课程具备完善的售后服务，免费更新、免费技术问答、免费岗位推荐
https://ke.qq.com/course/2738602

咨询QQ727585266
