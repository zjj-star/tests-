# Default

This example deploy Logstash 7.8.1 using [default values][].


## Usage

* Deploy Logstash chart with the default values: `make install`


## Testing

You can also run [goss integration tests][] using `make test`


[goss integration tests]: https://github.com/elastic/helm-charts/tree/7.8/logstash/examples/default/test/goss.yaml
[default values]: https://github.com/elastic/helm-charts/tree/7.8/logstash/values.yaml
